A few things about this pack!




0-No textures are safe. While this pack is live at the moment, it is not finished. That means that
ALL TEXTURES ARE SUBJECT TO CHANGE. You've been warned.

-Don't steal any textures. I'd made these all my hand. You can absolutely use this pack for inspiration
though, just don't trace or obviously steal textures.

0-DO NOT REDISTRIBUTE THIS PACK.

-you CAN edit this pack for your own personal use HOWEVER YOU MAY NOT REDISTRIBUTE THAT EDIT. Thank you.

0-Download for OFFICIAL SOURCES ONLY.







---MC FORUM POST: http://www.minecraftforum.net/forums/mapping-and-modding/resource-packs/wip-resource-pack/2855433-goodvibes-stylized-pack-optifine-support







Support my pack with a forum banner and give me suggestions on the forum! Otherwise, enjoy the pack. =(^owo^)=